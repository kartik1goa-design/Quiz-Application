// Expanded Quiz Questions Data Bank (Technology & Computer Fundamentals)
const quizDataBank = [
    {
        question: "What does HTML stand for?",
        options: [
            "Hyper Text Markup Language",
            "High Tech Modern Language",
            "Hyper Transfer Machine Language",
            "None of the above"
        ],
        answer: 0
    },
    {
        question: "Which CSS property is used to change the text color of an element?",
        options: ["font-color", "text-color", "color", "background-color"],
        answer: 2
    },
    {
        question: "Inside which HTML element do we put the JavaScript?",
        options: ["<script>", "<javascript>", "<js>", "<scripting>"],
        answer: 0
    },
    {
        question: "Which array method creates a new array with all elements that pass a test?",
        options: ["forEach()", "map()", "filter()", "reduce()"],
        answer: 2
    },
    {
        question: "What does CSS stand for?",
        options: [
            "Computer Style Sheets",
            "Cascading Style Sheets",
            "Creative Style System",
            "Colorful Style Sheets"
        ],
        answer: 1
    },
    {
        question: "Which keyword is used to declare a constant variable in JavaScript?",
        options: ["var", "let", "const", "static"],
        answer: 2
    },
    {
        question: "What is the output of typeof null in JavaScript?",
        options: ["null", "undefined", "object", "number"],
        answer: 2
    },
    {
        question: "Which of the following is NOT a JavaScript framework or library?",
        options: ["React", "Vue", "Laravel", "Angular"],
        answer: 2
    },
    {
        question: "What is the primary function of RAM in a computer?",
        options: [
            "Long-term data storage",
            "Temporary fast-access data storage",
            "Cooling down the CPU",
            "Processing graphical instructions"
        ],
        answer: 1
    },
    {
        question: "Which symbol is used for single-line comments in JavaScript?",
        options: ["<!-- -->", "/* */", "//", "#"],
        answer: 2
    },
    // Additional Questions
    {
        question: "What does API stand for?",
        options: [
            "Application Programming Interface",
            "Application Program Integration",
            "Automated Programming Interaction",
            "Advanced Process Interchange"
        ],
        answer: 0
    },
    {
        question: "Which protocol is used to secure web traffic (HTTPS)?",
        options: ["FTP", "HTTP", "SSL/TLS", "SMTP"],
        answer: 2
    },
    {
        question: "What does SQL stand for?",
        options: [
            "Simple Query Language",
            "Structured Query Language",
            "Sequential Query Language",
            "Standard Question Language"
        ],
        answer: 1
    },
    {
        question: "Which of these is a version control system?",
        options: ["Node.js", "Git", "HTML", "Docker"],
        answer: 1
    },
    {
        question: "What is the base-2 number system primarily consisting of 0s and 1s called?",
        options: ["Decimal", "Hexadecimal", "Binary", "Octal"],
        answer: 2
    }
];

// DOM Elements
const questionTracker = document.getElementById("question-tracker");
const timeLeftDisplay = document.getElementById("time-left");
const questionText = document.getElementById("question-text");
const optionsList = document.getElementById("options-list");
const nextBtn = document.getElementById("next-btn");
const quizHeader = document.getElementById("quiz-header");
const quizBody = document.getElementById("quiz-body");
const quizFooter = document.getElementById("quiz-footer");
const resultSection = document.getElementById("result-section");

const finalScore = document.getElementById("final-score");
const correctCount = document.getElementById("correct-count");
const wrongCount = document.getElementById("wrong-count");
const percentage = document.getElementById("percentage");
const performanceMsg = document.getElementById("performance-msg");
const restartBtn = document.getElementById("restart-btn");

// Quiz State Variables
let activeQuizQuestions = [];
let currentQuestionIndex = 0;
let score = 0;
let selectedOptionIndex = null;
let timer;
let timeLeft = 30;

// Initialize Quiz: Shuffles and picks 10 random questions every time
function startQuiz() {
    currentQuestionIndex = 0;
    score = 0;
    
    // Shuffle the master bank and slice the first 10 questions for this round
    activeQuizQuestions = [...quizDataBank].sort(() => Math.random() - 0.5).slice(0, 10);

    resultSection.classList.add("hidden");
    quizHeader.style.display = "flex";
    quizBody.style.display = "block";
    quizFooter.style.display = "flex";
    loadQuestion();
}

// Load Question Function
function loadQuestion() {
    resetTimer();
    selectedOptionIndex = null;
    nextBtn.disabled = true;

    const currentQuestion = activeQuizQuestions[currentQuestionIndex];
    questionTracker.textContent = `Question ${currentQuestionIndex + 1} of ${activeQuizQuestions.length}`;
    questionText.textContent = currentQuestion.question;

    optionsList.innerHTML = "";

    // Using forEach() array method to render options
    currentQuestion.options.forEach((optionText, index) => {
        const optionDiv = document.createElement("div");
        optionDiv.classList.add("option");
        optionDiv.textContent = optionText;
        optionDiv.addEventListener("click", () => selectOption(index, optionDiv));
        optionsList.appendChild(optionDiv);
    });
}

// Handle Option Selection
function selectOption(index, optionElement) {
    const allOptions = optionsList.querySelectorAll(".option");
    
    // Remove selected class from all options using forEach()
    allOptions.forEach(opt => opt.classList.remove("selected"));

    // Highlight selected option
    optionElement.classList.add("selected");
    selectedOptionIndex = index;
    nextBtn.disabled = false;
}

// Timer Functions
function startTimer() {
    timeLeft = 30;
    timeLeftDisplay.textContent = timeLeft;
    timer = setInterval(() => {
        timeLeft--;
        timeLeftDisplay.textContent = timeLeft;
        if (timeLeft <= 0) {
            clearInterval(timer);
            handleNextQuestion(); // Auto-submit/move on timeout
        }
    }, 1000);
}

function resetTimer() {
    clearInterval(timer);
    startTimer();
}

// Next Question Handler / Submission Logic
function handleNextQuestion() {
    clearInterval(timer);

    // Evaluate answer if selected
    if (selectedOptionIndex !== null) {
        if (selectedOptionIndex === activeQuizQuestions[currentQuestionIndex].answer) {
            score++;
        }
    }

    currentQuestionIndex++;

    // Conditional logic to check if quiz is finished
    if (currentQuestionIndex < activeQuizQuestions.length) {
        loadQuestion();
    } else {
        showResults();
    }
}

// Display Results Function
function showResults() {
    quizHeader.style.display = "none";
    quizBody.style.display = "none";
    quizFooter.style.display = "none";
    resultSection.classList.remove("hidden");

    const totalQ = activeQuizQuestions.length;
    const wrongAnswers = totalQ - score;
    const calcPercentage = Math.round((score / totalQ) * 100);

    // Update result card labels to match total questions dynamically
    document.querySelector(".score-card p:nth-child(1)").innerHTML = `Total Score: <span id="final-score">${score}</span> / ${totalQ}`;

    finalScore.textContent = score;
    correctCount.textContent = score;
    wrongCount.textContent = wrongAnswers;
    percentage.textContent = `${calcPercentage}%`;

    // Performance message conditional logic
    let message = "";
    let messageClass = "";
    if (calcPercentage >= 80) {
        message = "🌟 Excellent Performance!";
        messageClass = "success-text";
    } else if (calcPercentage >= 50) {
        message = "👍 Good Attempt!";
        messageClass = "";
    } else {
        message = "📚 Need More Practice!";
        messageClass = "error-text";
    }
    performanceMsg.textContent = message;
    performanceMsg.className = `performance-msg ${messageClass}`;
}

// Event Listeners
nextBtn.addEventListener("click", handleNextQuestion);
restartBtn.addEventListener("click", startQuiz);

// Initialize app on load
startQuiz();