Interactive Quiz Application (Frontend Only)

Project Overview
A responsive and dynamic web-based Quiz Application featuring multiple-choice questions centered around technology and computer fundamentals. Built with vanilla web technologies, it features automated timer management, real-time question tracking, stateful option selection, and performance evaluation.

Features Implemented
Dynamic Question Engine: Renders 10 distinct technical questions sequentially.
Interactive UI & Validation: Enforces option selection before allowing progression and highlights active choices smoothly.
Countdown Timer: Includes a 30-second per-question countdown timer that automatically triggers progression when time expires.
Comprehensive Scorecard: Calculates correct answers, wrong answers, and final percentage scores with performance custom messaging ("Excellent Performance", "Good Attempt", "Need More Practice").
Responsive Layout: Optimized card-based design supporting desktops, tablets, and mobile smartphones seamlessly.

Technologies Used
HTML5: Semantic structural layout.
CSS3: Modern styling, Flexbox layouts, gradients, transitions, and media queries.
JavaScript (ES6+): DOM manipulation, event handling, timers, array manipulation methods (`forEach()`, `filter()`, `map()`), and state handling.

Instructions to Run
1. Download or clone all three source files (`index.html`, `style.css`, and `script.js`) into the same local folder directory.
2. Open `index.html` directly in any modern web browser (Google Chrome, Mozilla Firefox, Microsoft Edge, Safari).